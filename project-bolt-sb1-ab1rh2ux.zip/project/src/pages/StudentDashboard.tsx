import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Trophy, Target, PlayCircle, BarChart3, Calendar, Users } from 'lucide-react';

const StudentDashboard: React.FC = () => {
  const [selectedCourse, setSelectedCourse] = useState('mathematics');

  const courses = [
    { id: 'mathematics', name: 'Mathematics', progress: 78, icon: '📊' },
    { id: 'science', name: 'Science', progress: 65, icon: '🔬' },
    { id: 'english', name: 'English', progress: 82, icon: '📚' },
    { id: 'history', name: 'History', progress: 73, icon: '🏛️' }
  ];

  const recentQuizzes = [
    { id: 1, title: 'Algebra Fundamentals', score: 85, date: '2024-01-15', topic: 'Mathematics' },
    { id: 2, title: 'Chemical Bonds', score: 92, date: '2024-01-14', topic: 'Science' },
    { id: 3, title: 'Shakespeare Analysis', score: 78, date: '2024-01-13', topic: 'English' },
    { id: 4, title: 'World War II', score: 88, date: '2024-01-12', topic: 'History' }
  ];

  const upcomingQuizzes = [
    { id: 5, title: 'Quadratic Equations', difficulty: 'Medium', estimatedTime: '15 min', topic: 'Mathematics' },
    { id: 6, title: 'Periodic Table', difficulty: 'Easy', estimatedTime: '10 min', topic: 'Science' },
    { id: 7, title: 'Grammar Rules', difficulty: 'Hard', estimatedTime: '20 min', topic: 'English' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, Alex!</h1>
          <p className="text-gray-600">Continue your learning journey with personalized AI-powered quizzes.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Score</p>
                <p className="text-2xl font-bold text-gray-900">1,247</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <Trophy className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Quizzes Completed</p>
                <p className="text-2xl font-bold text-gray-900">23</p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <Target className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Study Time</p>
                <p className="text-2xl font-bold text-gray-900">4.2h</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <Clock className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg. Score</p>
                <p className="text-2xl font-bold text-gray-900">82%</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <BarChart3 className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Course Progress */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Course Progress</h2>
              <div className="space-y-4">
                {courses.map((course) => (
                  <div key={course.id} className="flex items-center space-x-4">
                    <div className="text-2xl">{course.icon}</div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center mb-1">
                        <h3 className="font-medium text-gray-900">{course.name}</h3>
                        <span className="text-sm text-gray-600">{course.progress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${course.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Quizzes */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Quiz Results</h2>
              <div className="space-y-4">
                {recentQuizzes.map((quiz) => (
                  <div key={quiz.id} className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <div className="flex items-center space-x-3">
                      <div className="bg-blue-100 p-2 rounded-lg">
                        <BookOpen className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{quiz.title}</h3>
                        <p className="text-sm text-gray-600">{quiz.topic} • {quiz.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                        quiz.score >= 80 ? 'bg-green-100 text-green-700' :
                        quiz.score >= 60 ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {quiz.score}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <Link
                  to="/diagnostic"
                  className="flex items-center space-x-3 p-3 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg hover:from-indigo-100 hover:to-purple-100 transition-all duration-200"
                >
                  <Target className="h-5 w-5 text-indigo-600" />
                  <span className="font-medium text-gray-900">Take Diagnostic Test</span>
                </Link>
                
                <Link
                  to="/sync"
                  className="flex items-center space-x-3 p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg hover:from-green-100 hover:to-emerald-100 transition-all duration-200"
                >
                  <Users className="h-5 w-5 text-green-600" />
                  <span className="font-medium text-gray-900">Sync Google Classroom</span>
                </Link>
                
                <Link
                  to="/analytics"
                  className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg hover:from-blue-100 hover:to-cyan-100 transition-all duration-200"
                >
                  <BarChart3 className="h-5 w-5 text-blue-600" />
                  <span className="font-medium text-gray-900">View Analytics</span>
                </Link>
              </div>
            </div>

            {/* Upcoming Quizzes */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Recommended Quizzes</h2>
              <div className="space-y-3">
                {upcomingQuizzes.map((quiz) => (
                  <div key={quiz.id} className="border border-gray-100 rounded-lg p-4 hover:bg-gray-50 transition-colors duration-200">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-gray-900">{quiz.title}</h3>
                      <Link
                        to={`/quiz/${quiz.id}`}
                        className="text-indigo-600 hover:text-indigo-700"
                      >
                        <PlayCircle className="h-5 w-5" />
                      </Link>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>{quiz.difficulty}</span>
                      <span>{quiz.estimatedTime}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;