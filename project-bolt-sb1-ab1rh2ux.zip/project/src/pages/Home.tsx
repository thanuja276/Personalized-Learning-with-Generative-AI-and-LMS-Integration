import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Brain, BookOpen, Users, BarChart3, Zap, Target, Globe } from 'lucide-react';

const Home: React.FC = () => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="mb-8">
              <div className="inline-flex items-center space-x-2 bg-indigo-50 px-4 py-2 rounded-full text-indigo-600 text-sm font-medium">
                <Brain className="h-4 w-4" />
                <span>Powered by IBM Watsonx & Granite AI</span>
              </div>
            </div>
            
            <h1 className="text-4xl sm:text-6xl font-bold text-gray-900 mb-6">
              Personalized Learning with
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent block">
                Generative AI
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              EduTutor AI revolutionizes education with dynamic quiz generation, real-time feedback, 
              and seamless Google Classroom integration—all powered by advanced IBM Granite models.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {user ? (
                <Link
                  to={user.role === 'student' ? '/student' : '/educator'}
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
                >
                  Go to Dashboard
                </Link>
              ) : (
                <>
                  <Link
                    to="/login"
                    className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
                  >
                    Get Started
                  </Link>
                  <Link
                    to="#features"
                    className="bg-white text-gray-700 px-8 py-3 rounded-lg border border-gray-300 hover:border-indigo-300 hover:text-indigo-600 transition-all duration-200 font-medium"
                  >
                    Learn More
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Powerful Features for Modern Education
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Experience the future of personalized learning with AI-powered tools designed for students and educators.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl hover:shadow-lg transition-shadow duration-200">
              <div className="bg-indigo-100 p-3 rounded-lg w-fit mb-4">
                <Brain className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">AI-Powered Quiz Generation</h3>
              <p className="text-gray-600">
                Dynamic quiz creation using IBM Granite models that adapt to student learning patterns and curriculum requirements.
              </p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl hover:shadow-lg transition-shadow duration-200">
              <div className="bg-green-100 p-3 rounded-lg w-fit mb-4">
                <Target className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Adaptive Learning</h3>
              <p className="text-gray-600">
                Personalized difficulty adjustment based on diagnostic testing and real-time performance analytics.
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl hover:shadow-lg transition-shadow duration-200">
              <div className="bg-blue-100 p-3 rounded-lg w-fit mb-4">
                <Globe className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Google Classroom Integration</h3>
              <p className="text-gray-600">
                Seamless synchronization with Google Classroom for automatic course data and student management.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl hover:shadow-lg transition-shadow duration-200">
              <div className="bg-purple-100 p-3 rounded-lg w-fit mb-4">
                <BarChart3 className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Real-Time Analytics</h3>
              <p className="text-gray-600">
                Comprehensive performance insights and progress tracking for both students and educators.
              </p>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-red-50 p-6 rounded-xl hover:shadow-lg transition-shadow duration-200">
              <div className="bg-orange-100 p-3 rounded-lg w-fit mb-4">
                <Zap className="h-6 w-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Instant Feedback</h3>
              <p className="text-gray-600">
                Immediate response evaluation and detailed explanations powered by advanced AI models.
              </p>
            </div>

            <div className="bg-gradient-to-br from-teal-50 to-green-50 p-6 rounded-xl hover:shadow-lg transition-shadow duration-200">
              <div className="bg-teal-100 p-3 rounded-lg w-fit mb-4">
                <Users className="h-6 w-6 text-teal-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Multi-Role Support</h3>
              <p className="text-gray-600">
                Dedicated interfaces for students and educators with role-specific features and insights.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-indigo-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Transform Your Learning Experience?
          </h2>
          <p className="text-xl text-indigo-100 mb-8">
            Join thousands of students and educators already using EduTutor AI to achieve better learning outcomes.
          </p>
          <Link
            to="/login"
            className="bg-white text-indigo-600 px-8 py-3 rounded-lg hover:bg-gray-50 transition-colors duration-200 font-medium inline-flex items-center space-x-2"
          >
            <BookOpen className="h-5 w-5" />
            <span>Start Learning Today</span>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;