import React, { useState } from 'react';
import { BarChart3, TrendingUp, Users, Clock, Award, Target, Calendar, Download } from 'lucide-react';

const Analytics: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  const [selectedMetric, setSelectedMetric] = useState('performance');

  const performanceData = [
    { subject: 'Mathematics', avgScore: 82, improvement: 12, students: 28 },
    { subject: 'Science', avgScore: 78, improvement: 8, students: 24 },
    { subject: 'English', avgScore: 85, improvement: 15, students: 32 },
    { subject: 'History', avgScore: 79, improvement: 5, students: 18 }
  ];

  const topicDifficulty = [
    { topic: 'Quadratic Equations', difficulty: 'Hard', avgScore: 65, attempts: 45 },
    { topic: 'Chemical Bonds', difficulty: 'Medium', avgScore: 78, attempts: 38 },
    { topic: 'Essay Writing', difficulty: 'Easy', avgScore: 88, attempts: 52 },
    { topic: 'World War II', difficulty: 'Medium', avgScore: 76, attempts: 29 }
  ];

  const learningTrends = [
    { period: 'Week 1', quizzes: 25, avgScore: 75, studyTime: 120 },
    { period: 'Week 2', quizzes: 32, avgScore: 78, studyTime: 135 },
    { period: 'Week 3', quizzes: 28, avgScore: 82, studyTime: 140 },
    { period: 'Week 4', quizzes: 35, avgScore: 85, studyTime: 155 }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Learning Analytics</h1>
              <p className="text-gray-600">AI-powered insights into learning patterns and performance</p>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="week">This Week</option>
                <option value="month">This Month</option>
                <option value="quarter">This Quarter</option>
              </select>
              <button className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2">
                <Download className="h-4 w-4" />
                <span>Export Report</span>
              </button>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Quizzes</p>
                <p className="text-2xl font-bold text-gray-900">120</p>
                <p className="text-sm text-green-600">↑ 15% from last week</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Performance</p>
                <p className="text-2xl font-bold text-gray-900">81%</p>
                <p className="text-sm text-green-600">↑ 8% improvement</p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Study Time</p>
                <p className="text-2xl font-bold text-gray-900">8.5h</p>
                <p className="text-sm text-green-600">↑ 12% increase</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <Clock className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Learners</p>
                <p className="text-2xl font-bold text-gray-900">102</p>
                <p className="text-sm text-green-600">↑ 5 new students</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <Users className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Performance by Subject */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Performance by Subject</h2>
              <div className="space-y-4">
                {performanceData.map((item, index) => (
                  <div key={index} className="border border-gray-100 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="font-medium text-gray-900">{item.subject}</h3>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-600">{item.students} students</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          item.improvement > 10 ? 'bg-green-100 text-green-700' :
                          item.improvement > 5 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {item.improvement > 0 ? '+' : ''}{item.improvement}%
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="flex-1">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${item.avgScore}%` }}
                          ></div>
                        </div>
                      </div>
                      <span className="text-sm font-medium text-gray-900">{item.avgScore}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Learning Trends */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Learning Trends</h2>
              <div className="h-64 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <TrendingUp className="h-12 w-12 text-indigo-400 mx-auto mb-2" />
                  <p className="text-gray-600">Interactive trend charts would appear here</p>
                  <p className="text-sm text-gray-500">Showing quiz performance over time</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Topic Difficulty */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Topic Difficulty Analysis</h2>
              <div className="space-y-3">
                {topicDifficulty.map((topic, index) => (
                  <div key={index} className="border border-gray-100 rounded-lg p-3">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="font-medium text-gray-900 text-sm">{topic.topic}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        topic.difficulty === 'Hard' ? 'bg-red-100 text-red-700' :
                        topic.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {topic.difficulty}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-600">
                      <span>{topic.attempts} attempts</span>
                      <span>{topic.avgScore}% avg</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Insights */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Insights</h2>
              <div className="space-y-3">
                <div className="bg-white p-3 rounded-lg">
                  <div className="flex items-center space-x-2 mb-1">
                    <Target className="h-4 w-4 text-indigo-600" />
                    <span className="text-sm font-medium text-gray-900">Learning Pattern</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Students perform best during morning sessions (9-11 AM)
                  </p>
                </div>
                
                <div className="bg-white p-3 rounded-lg">
                  <div className="flex items-center space-x-2 mb-1">
                    <Award className="h-4 w-4 text-green-600" />
                    <span className="text-sm font-medium text-gray-900">Recommendation</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Focus on quadratic equations - lowest performance area
                  </p>
                </div>
                
                <div className="bg-white p-3 rounded-lg">
                  <div className="flex items-center space-x-2 mb-1">
                    <Calendar className="h-4 w-4 text-purple-600" />
                    <span className="text-sm font-medium text-gray-900">Trend Alert</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Science performance improving 8% this month
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Stats</h2>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Most Active Day</span>
                  <span className="text-sm font-medium text-gray-900">Wednesday</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Peak Study Time</span>
                  <span className="text-sm font-medium text-gray-900">10:00 AM</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Completion Rate</span>
                  <span className="text-sm font-medium text-gray-900">94%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Avg Quiz Time</span>
                  <span className="text-sm font-medium text-gray-900">12 min</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;