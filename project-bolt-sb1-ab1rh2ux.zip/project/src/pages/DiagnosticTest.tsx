import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, Target, Clock, CheckCircle, ArrowRight, BarChart3 } from 'lucide-react';

const DiagnosticTest: React.FC = () => {
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<(string | null)[]>([]);
  const [isStarted, setIsStarted] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const diagnosticQuestions = [
    {
      id: 1,
      question: 'What is your current comfort level with algebra?',
      options: ['Beginner', 'Intermediate', 'Advanced', 'Expert'],
      category: 'Mathematics'
    },
    {
      id: 2,
      question: 'How familiar are you with scientific method?',
      options: ['Never heard of it', 'Basic understanding', 'Comfortable', 'Very familiar'],
      category: 'Science'
    },
    {
      id: 3,
      question: 'What best describes your essay writing skills?',
      options: ['Need help with structure', 'Can write basic essays', 'Write well-organized essays', 'Advanced writing skills'],
      category: 'English'
    },
    {
      id: 4,
      question: 'How do you prefer to learn new concepts?',
      options: ['Visual aids and diagrams', 'Reading and text', 'Hands-on practice', 'Discussion and explanation'],
      category: 'Learning Style'
    },
    {
      id: 5,
      question: 'What is your biggest challenge in learning?',
      options: ['Staying focused', 'Understanding complex concepts', 'Remembering information', 'Applying knowledge'],
      category: 'Learning Challenges'
    }
  ];

  const handleStart = () => {
    setIsStarted(true);
    setAnswers(new Array(diagnosticQuestions.length).fill(null));
  };

  const handleAnswerSelect = (answerIndex: string) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < diagnosticQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const generateRecommendations = () => {
    const mathLevel = answers[0] ? parseInt(answers[0]) : 0;
    const scienceLevel = answers[1] ? parseInt(answers[1]) : 0;
    const englishLevel = answers[2] ? parseInt(answers[2]) : 0;
    const learningStyle = answers[3] ? parseInt(answers[3]) : 0;

    const recommendations = [];

    if (mathLevel <= 1) {
      recommendations.push({
        subject: 'Mathematics',
        level: 'Beginner',
        topics: ['Basic arithmetic', 'Introduction to algebra', 'Geometry fundamentals'],
        difficulty: 'Easy'
      });
    } else if (mathLevel <= 2) {
      recommendations.push({
        subject: 'Mathematics',
        level: 'Intermediate',
        topics: ['Linear equations', 'Quadratic equations', 'Trigonometry basics'],
        difficulty: 'Medium'
      });
    } else {
      recommendations.push({
        subject: 'Mathematics',
        level: 'Advanced',
        topics: ['Calculus', 'Advanced algebra', 'Statistics'],
        difficulty: 'Hard'
      });
    }

    if (scienceLevel <= 1) {
      recommendations.push({
        subject: 'Science',
        level: 'Beginner',
        topics: ['Basic chemistry', 'Introduction to physics', 'Biology fundamentals'],
        difficulty: 'Easy'
      });
    } else {
      recommendations.push({
        subject: 'Science',
        level: 'Intermediate',
        topics: ['Chemical reactions', 'Motion and forces', 'Cell biology'],
        difficulty: 'Medium'
      });
    }

    return recommendations;
  };

  if (!isStarted) {
    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-4 rounded-full w-fit mx-auto mb-6">
              <Target className="h-12 w-12 text-white" />
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Diagnostic Assessment
            </h1>
            
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              This AI-powered diagnostic test will analyze your learning level and preferences to create 
              a personalized learning path tailored just for you.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl">
                <Brain className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">AI-Powered Analysis</h3>
                <p className="text-sm text-gray-600">
                  Our IBM Granite model analyzes your responses to understand your learning style
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl">
                <Clock className="h-8 w-8 text-green-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Quick Assessment</h3>
                <p className="text-sm text-gray-600">
                  Only 5 questions that take less than 3 minutes to complete
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl">
                <BarChart3 className="h-8 w-8 text-purple-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Personalized Results</h3>
                <p className="text-sm text-gray-600">
                  Get customized learning recommendations based on your profile
                </p>
              </div>
            </div>

            <button
              onClick={handleStart}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium text-lg"
            >
              Start Diagnostic Test
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (showResults) {
    const recommendations = generateRecommendations();
    
    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="text-center mb-8">
              <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-4 rounded-full w-fit mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Diagnostic Complete!</h1>
              <p className="text-gray-600">Here are your personalized learning recommendations</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {recommendations.map((rec, index) => (
                <div key={index} className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-100">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{rec.subject}</h3>
                  <div className="mb-3">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      rec.difficulty === 'Easy' ? 'bg-green-100 text-green-700' :
                      rec.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-red-100 text-red-700'
                    }`}>
                      {rec.level} Level
                    </span>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Recommended Topics:</h4>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {rec.topics.map((topic, idx) => (
                        <li key={idx} className="flex items-center space-x-2">
                          <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div>
                          <span>{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-6 rounded-xl mb-8">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">AI Learning Insights</h3>
              <div className="space-y-3 text-sm text-gray-700">
                <p>• Based on your responses, you learn best through interactive practice and visual aids</p>
                <p>• Your analytical skills are developing well - focus on applying concepts to real-world problems</p>
                <p>• Consider studying in 25-minute focused sessions with short breaks for optimal retention</p>
              </div>
            </div>

            <div className="flex justify-center space-x-4">
              <button
                onClick={() => navigate('/student')}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium"
              >
                View My Dashboard
              </button>
              <button
                onClick={() => navigate('/quiz/1')}
                className="bg-white text-gray-700 px-8 py-3 rounded-lg border border-gray-300 hover:border-gray-400 transition-all duration-200 font-medium flex items-center space-x-2"
              >
                <span>Start First Quiz</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = diagnosticQuestions[currentQuestion];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Progress */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Diagnostic Progress</span>
            <span className="text-sm text-gray-600">
              {currentQuestion + 1} of {diagnosticQuestions.length}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / diagnosticQuestions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Question */}
        <div className="bg-white rounded-xl shadow-sm p-8">
          <div className="mb-4">
            <span className="text-sm font-medium text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
              {currentQ.category}
            </span>
          </div>
          
          <h2 className="text-xl font-semibold text-gray-900 mb-6">
            {currentQ.question}
          </h2>

          <div className="space-y-3 mb-8">
            {currentQ.options.map((option, index) => (
              <label
                key={index}
                className={`block p-4 border-2 rounded-lg cursor-pointer transition-all duration-200 ${
                  answers[currentQuestion] === index.toString()
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <input
                  type="radio"
                  name={`question-${currentQuestion}`}
                  value={index}
                  checked={answers[currentQuestion] === index.toString()}
                  onChange={(e) => handleAnswerSelect(e.target.value)}
                  className="sr-only"
                />
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded-full border-2 ${
                    answers[currentQuestion] === index.toString()
                      ? 'border-indigo-500 bg-indigo-500'
                      : 'border-gray-300'
                  }`}>
                    {answers[currentQuestion] === index.toString() && (
                      <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                    )}
                  </div>
                  <span className="text-gray-700">{option}</span>
                </div>
              </label>
            ))}
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleNext}
              disabled={answers[currentQuestion] === null}
              className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center space-x-2"
            >
              <span>{currentQuestion === diagnosticQuestions.length - 1 ? 'Finish' : 'Next'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiagnosticTest;