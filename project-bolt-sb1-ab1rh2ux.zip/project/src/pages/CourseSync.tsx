import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, CheckCircle, Clock, BookOpen, Calendar, Download, RefreshCw } from 'lucide-react';

const CourseSync: React.FC = () => {
  const navigate = useNavigate();
  const [isConnected, setIsConnected] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [courses, setCourses] = useState<any[]>([]);

  const handleGoogleConnect = async () => {
    setIsLoading(true);
    // Simulate Google OAuth flow
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockCourses = [
      {
        id: 'math-101',
        name: 'Mathematics 101',
        teacher: 'Dr. Smith',
        students: 28,
        subjects: ['Algebra', 'Geometry', 'Trigonometry'],
        lastSync: new Date(),
        status: 'active'
      },
      {
        id: 'sci-201',
        name: 'Science 201',
        teacher: 'Prof. Johnson',
        students: 24,
        subjects: ['Chemistry', 'Physics', 'Biology'],
        lastSync: new Date(),
        status: 'active'
      },
      {
        id: 'eng-102',
        name: 'English 102',
        teacher: 'Ms. Brown',
        students: 32,
        subjects: ['Literature', 'Writing', 'Grammar'],
        lastSync: new Date(),
        status: 'active'
      },
      {
        id: 'hist-301',
        name: 'History 301',
        teacher: 'Dr. Wilson',
        students: 18,
        subjects: ['World History', 'American History'],
        lastSync: new Date(),
        status: 'active'
      }
    ];
    
    setCourses(mockCourses);
    setIsConnected(true);
    setIsLoading(false);
  };

  const handleSync = async (courseId: string) => {
    setIsLoading(true);
    // Simulate sync process
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsLoading(false);
  };

  if (!isConnected) {
    return (
      <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 rounded-full w-fit mx-auto mb-6">
              <Users className="h-12 w-12 text-white" />
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Google Classroom Integration
            </h1>
            
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              Connect your Google Classroom account to automatically sync your courses, students, 
              and assignments. Our AI will generate personalized quizzes based on your curriculum.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl">
                <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Automatic Sync</h3>
                <p className="text-sm text-gray-600">
                  Seamlessly import your classes, students, and course content
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl">
                <BookOpen className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Smart Quiz Generation</h3>
                <p className="text-sm text-gray-600">
                  AI creates relevant quizzes based on your curriculum topics
                </p>
              </div>
              
              <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-xl">
                <Calendar className="h-8 w-8 text-purple-600 mx-auto mb-3" />
                <h3 className="font-semibold text-gray-900 mb-2">Real-time Updates</h3>
                <p className="text-sm text-gray-600">
                  Stay synchronized with your classroom activities and assignments
                </p>
              </div>
            </div>

            <button
              onClick={handleGoogleConnect}
              disabled={isLoading}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-8 py-3 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 font-medium text-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-3 mx-auto"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Connecting...</span>
                </>
              ) : (
                <>
                  <Users className="h-5 w-5" />
                  <span>Connect Google Classroom</span>
                </>
              )}
            </button>

            <p className="text-sm text-gray-500 mt-4">
              Your data is secure and encrypted. We only access course information.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 mb-2">Google Classroom Sync</h1>
              <p className="text-gray-600">Manage your connected courses and sync data</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2 text-green-600">
                <CheckCircle className="h-5 w-5" />
                <span className="font-medium">Connected</span>
              </div>
              <button
                onClick={() => handleSync('all')}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 flex items-center space-x-2"
              >
                <RefreshCw className="h-4 w-4" />
                <span>Sync All</span>
              </button>
            </div>
          </div>
        </div>

        {/* Course Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {courses.map((course) => (
            <div key={course.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{course.name}</h3>
                  <p className="text-gray-600">{course.teacher}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                    {course.status}
                  </div>
                </div>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Users className="h-4 w-4" />
                  <span>{course.students} students</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Clock className="h-4 w-4" />
                  <span>Last sync: {course.lastSync.toLocaleString()}</span>
                </div>
              </div>

              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Subjects:</h4>
                <div className="flex flex-wrap gap-2">
                  {course.subjects.map((subject, index) => (
                    <span key={index} className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded text-xs">
                      {subject}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => handleSync(course.id)}
                  disabled={isLoading}
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  {isLoading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                  <span>Sync</span>
                </button>
                <button className="px-4 py-2 text-gray-600 border border-gray-300 rounded-lg hover:border-gray-400 transition-all duration-200 flex items-center space-x-2">
                  <Download className="h-4 w-4" />
                  <span>Export</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* AI Insights */}
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 mt-6 border border-indigo-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Sync Insights</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Quiz Generation Ready</h4>
              <p className="text-sm text-gray-600">
                Based on your curriculum, we've identified 23 topics ready for AI-generated quizzes.
              </p>
            </div>
            <div className="bg-white p-4 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Student Performance</h4>
              <p className="text-sm text-gray-600">
                102 students across 4 classes are ready for personalized learning assessments.
              </p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-8 flex justify-center">
          <button
            onClick={() => navigate('/student')}
            className="bg-white text-gray-700 px-6 py-3 rounded-lg border border-gray-300 hover:border-gray-400 transition-all duration-200 font-medium"
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
};

export default CourseSync;