import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, BookOpen, BarChart3, Clock, TrendingUp, Award, Calendar, Plus } from 'lucide-react';

const EducatorDashboard: React.FC = () => {
  const [selectedClass, setSelectedClass] = useState('math-101');

  const classes = [
    { id: 'math-101', name: 'Mathematics 101', students: 28, avgScore: 82 },
    { id: 'sci-201', name: 'Science 201', students: 24, avgScore: 78 },
    { id: 'eng-102', name: 'English 102', students: 32, avgScore: 85 },
    { id: 'hist-301', name: 'History 301', students: 18, avgScore: 79 }
  ];

  const recentActivity = [
    { id: 1, student: 'Alex Johnson', quiz: 'Algebra Fundamentals', score: 85, time: '2 hours ago' },
    { id: 2, student: 'Sarah Chen', quiz: 'Quadratic Equations', score: 92, time: '3 hours ago' },
    { id: 3, student: 'Mike Rodriguez', quiz: 'Trigonometry', score: 78, time: '5 hours ago' },
    { id: 4, student: 'Emma Davis', quiz: 'Geometry Basics', score: 88, time: '1 day ago' }
  ];

  const topPerformers = [
    { name: 'Sarah Chen', score: 94, quizzes: 12 },
    { name: 'Alex Johnson', score: 89, quizzes: 15 },
    { name: 'Emma Davis', score: 87, quizzes: 11 },
    { name: 'Mike Rodriguez', score: 85, quizzes: 13 }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Educator Dashboard</h1>
          <p className="text-gray-600">Monitor student progress and manage your classes with AI-powered insights.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Students</p>
                <p className="text-2xl font-bold text-gray-900">102</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Classes</p>
                <p className="text-2xl font-bold text-gray-900">4</p>
              </div>
              <div className="bg-green-100 p-3 rounded-lg">
                <BookOpen className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Quizzes Created</p>
                <p className="text-2xl font-bold text-gray-900">47</p>
              </div>
              <div className="bg-purple-100 p-3 rounded-lg">
                <BarChart3 className="h-6 w-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg. Class Score</p>
                <p className="text-2xl font-bold text-gray-900">81%</p>
              </div>
              <div className="bg-orange-100 p-3 rounded-lg">
                <TrendingUp className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Class Selector */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Class Overview</h2>
            <button className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Create Quiz</span>
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {classes.map((classItem) => (
              <div
                key={classItem.id}
                onClick={() => setSelectedClass(classItem.id)}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 ${
                  selectedClass === classItem.id
                    ? 'border-indigo-500 bg-indigo-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <h3 className="font-medium text-gray-900 mb-2">{classItem.name}</h3>
                <div className="flex justify-between text-sm text-gray-600">
                  <span>{classItem.students} students</span>
                  <span>{classItem.avgScore}% avg</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Student Activity</h2>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center justify-between p-4 border border-gray-100 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                    <div className="flex items-center space-x-3">
                      <div className="bg-indigo-100 p-2 rounded-lg">
                        <BookOpen className="h-4 w-4 text-indigo-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900">{activity.student}</h3>
                        <p className="text-sm text-gray-600">{activity.quiz} • {activity.time}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                        activity.score >= 80 ? 'bg-green-100 text-green-700' :
                        activity.score >= 60 ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {activity.score}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Performance Chart Placeholder */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Class Performance Trends</h2>
              <div className="h-64 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="h-12 w-12 text-indigo-400 mx-auto mb-2" />
                  <p className="text-gray-600">Interactive performance charts would appear here</p>
                  <p className="text-sm text-gray-500">Powered by AI analytics</p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Top Performers */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Top Performers</h2>
              <div className="space-y-3">
                {topPerformers.map((student, index) => (
                  <div key={student.name} className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      index === 0 ? 'bg-yellow-100 text-yellow-700' :
                      index === 1 ? 'bg-gray-100 text-gray-700' :
                      index === 2 ? 'bg-orange-100 text-orange-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{student.name}</h3>
                      <p className="text-sm text-gray-600">{student.quizzes} quizzes completed</p>
                    </div>
                    <div className="text-right">
                      <div className="bg-green-100 text-green-700 px-2 py-1 rounded text-sm font-medium">
                        {student.score}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="space-y-3">
                <Link
                  to="/sync"
                  className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg hover:from-blue-100 hover:to-cyan-100 transition-all duration-200"
                >
                  <Users className="h-5 w-5 text-blue-600" />
                  <span className="font-medium text-gray-900">Sync Google Classroom</span>
                </Link>
                
                <Link
                  to="/analytics"
                  className="flex items-center space-x-3 p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg hover:from-purple-100 hover:to-pink-100 transition-all duration-200"
                >
                  <BarChart3 className="h-5 w-5 text-purple-600" />
                  <span className="font-medium text-gray-900">View Detailed Analytics</span>
                </Link>
                
                <button className="flex items-center space-x-3 p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg hover:from-green-100 hover:to-emerald-100 transition-all duration-200 w-full">
                  <Award className="h-5 w-5 text-green-600" />
                  <span className="font-medium text-gray-900">Generate Report</span>
                </button>
              </div>
            </div>

            {/* AI Insights */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Insights</h2>
              <div className="space-y-3">
                <div className="bg-white p-3 rounded-lg">
                  <p className="text-sm text-gray-700">
                    <strong>Recommendation:</strong> Students show difficulty with quadratic equations. 
                    Consider creating additional practice quizzes.
                  </p>
                </div>
                <div className="bg-white p-3 rounded-lg">
                  <p className="text-sm text-gray-700">
                    <strong>Trend:</strong> Class performance improved 12% over the last month.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EducatorDashboard;