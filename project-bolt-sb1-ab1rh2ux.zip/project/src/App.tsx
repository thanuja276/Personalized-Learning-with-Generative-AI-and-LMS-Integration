import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Login from './pages/Login';
import StudentDashboard from './pages/StudentDashboard';
import EducatorDashboard from './pages/EducatorDashboard';
import Quiz from './pages/Quiz';
import DiagnosticTest from './pages/DiagnosticTest';
import CourseSync from './pages/CourseSync';
import Analytics from './pages/Analytics';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/student" element={<StudentDashboard />} />
            <Route path="/educator" element={<EducatorDashboard />} />
            <Route path="/quiz/:id" element={<Quiz />} />
            <Route path="/diagnostic" element={<DiagnosticTest />} />
            <Route path="/sync" element={<CourseSync />} />
            <Route path="/analytics" element={<Analytics />} />
          </Routes>
        </Layout>
      </Router>
    </AuthProvider>
  );
}

export default App;